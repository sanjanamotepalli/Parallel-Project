package com.bank.services;

import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public interface BankServiceI {
     boolean makeAccount(String name,String phoneNo, String password, long accountNo,int balance) throws AccountNotCreatedException;
     
     int getBalance1(long accountNo) throws ZeroBalanceException;
     int depositAmount(long accountNo, int deposit);
     int withdrawAmount(long accountNo, int withdraw) throws InsufficientBalanceException;
     boolean fundTransfer(long accountNo , long accno,int amount);
     boolean validateAccount(long accountNo,String password);
}
