package com.bank.services;

import com.bank.beans.BankBean;
import com.bank.dao.BankDAO;
import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public class BankService implements BankServiceI
{
	int balance;
	BankDAO bankDAO =  new BankDAO();
	BankBean bankBean = new BankBean();
	
	public boolean makeAccount(String name,String phoneNo, String password, long accountNo,int balance) throws AccountNotCreatedException
	{
		BankBean bankBean = new BankBean();
	    bankBean.setName(name);
	    bankBean.setPhoneNo(phoneNo);
	    bankBean.setPassword(password);
	    bankBean.setAccountNo(accountNo);
	    bankBean.setBalance(balance);
	    bankBean.setMini("account created \n Amount deposited Rs."+ balance );
	    
	    boolean result = bankDAO.createAccount(bankBean);
	    return result;
      
     }
	public int getBalance1(long accountNo) throws ZeroBalanceException
	{
		  balance = bankDAO.showBalance(accountNo);
		 return balance;
	}
	public int depositAmount(long accountNo,int deposit)
	{
		 balance = bankDAO.depositBalance(accountNo, deposit);
		return balance;
	}
	public int withdrawAmount(long accountNo , int withdraw) throws InsufficientBalanceException
	{
		balance =bankDAO.withdrawBalance(accountNo, withdraw);
		return balance;
	}
	public boolean fundTransfer(long accountNo, long accno , int amount)
	{
		boolean transfer = bankDAO.transferFund(accountNo,accno,amount);
		return transfer;
	}
	public boolean validateAccount(long accountNo, String password)
	{
		boolean b = bankDAO.accountValidate(accountNo,password);
		return b;
	}
	public String miniStatement(long accountNo)
	{
		String mini =bankDAO.miniStatement(accountNo);
		return mini;
	}
	public int nameValidate(String name)
	{
		if(name.matches("[A-Z][a-zA-Z]*"))
			return 1;
		else
			return 0;
	}
	public int mobNoValidate(String phoneNo)
	{
		
	if(phoneNo.matches("[a-z]*")||phoneNo.matches("[A-Z]*"))
		return 0;
	else
		if(phoneNo.matches("[6-9][0-9]{9}"))
				return 1;
		else
			return 0;
	}
	public int passwordValidate(String password) 
	{
		if(password.length()>3)
			return 1;
		else
			return 0;
	}
	public int checkBalance(int balance) {
		if(balance>=1000)
		return 1;
		else 
			return 0;
	}
}