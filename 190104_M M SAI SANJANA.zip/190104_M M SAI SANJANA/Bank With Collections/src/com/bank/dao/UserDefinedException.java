package com.bank.dao;

import java.util.Scanner;

class MobileNumberException extends Exception
{
	public String toString()
	{
		return "mobile number should be of 10 digit";
	}
}
public class UserDefinedException
{
	static void checkMobile(String mobile) throws MobileNumberException
	{
		if(mobile.length()<10||mobile.length()>10)
			throw new MobileNumberException();
		else
			System.out.println(mobile);
	}
  public static void main(String[] args) throws MobileNumberException {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter mobile number");
	  String mobile = sc.next();
	UserDefinedException.checkMobile(mobile);
	
} 
}
