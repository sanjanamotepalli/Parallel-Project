import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import { FormsModule} from '@angular/forms'
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ServicelayerService } from './servicelayer.service';
import { UseractionComponent } from './useraction/useraction.component';
import { FundsComponent } from './useraction/funds/funds.component';
import { TransactionComponent } from './useraction/transaction/transaction.component';
import { DepositComponent } from './useraction/deposit/deposit.component';
import { WithdrawlComponent } from './useraction/withdrawl/withdrawl.component';
import { BalanceComponent } from './useraction/balance/balance.component';


@NgModule({
  declarations: [
    AppComponent,
    DepositComponent,
    WithdrawlComponent,
    FundsComponent,
    TransactionComponent,
    CreateComponent,
    UseractionComponent,
    BalanceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule
  ],
  providers: [HttpClient,ServicelayerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
