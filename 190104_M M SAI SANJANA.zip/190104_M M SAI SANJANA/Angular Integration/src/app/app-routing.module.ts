import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateComponent } from './create/create.component';

import { UseractionComponent } from './useraction/useraction.component';
import { BalanceComponent } from './useraction/balance/balance.component';
import { DepositComponent } from './useraction/deposit/deposit.component';
import { WithdrawlComponent } from './useraction/withdrawl/withdrawl.component';
import { FundsComponent } from './useraction/funds/funds.component';
import { TransactionComponent } from './useraction/transaction/transaction.component';



const routes: Routes = [
  {path:"create",component:CreateComponent},
  
  {path:"useraction",component:UseractionComponent},

  {path:"balance",component:BalanceComponent},

  {path:"deposit",component:DepositComponent},

  {path:  "withdraw" ,component: WithdrawlComponent},

  {path: "fund"  ,component:FundsComponent },

  {path:  "transaction" ,component:TransactionComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
