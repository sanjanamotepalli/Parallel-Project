package com.cap.entity;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction_details1")
public class TransactionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long transId;
	private long baccInitial;
	private int baccFinal;  //initialbalance
	private String transMetd;
	private Integer transBal;//finalbalance
	private Date transdate;
	

	
	@Override
	public String toString() {
		return "TransactionEntity [transId=" + transId + ", baccInitial=" + baccInitial + ", baccFinal=" + baccFinal
				+ ", transMetd=" + transMetd + ", transBal=" + transBal + ", transdate=" + transdate + "]";
	}
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getBaccInitial() {
		return baccInitial;
	}
	public void setBaccInitial(long baccInitial) {
		this.baccInitial = baccInitial;
	}
	public int getBaccFinal() {
		return baccFinal;
	}
	public void setBaccFinal(int baccFinal) {
		this.baccFinal = baccFinal;
	}
	public String getTransMetd() {
		return transMetd;
	}
	public void setTransMetd(String transMetd) {
		this.transMetd = transMetd;
	}
	public Integer getTransBal() {
		return transBal;
	}
	public void setTransBal(Integer transBal) {
		this.transBal = transBal;
	}
	public Date getTransdate() {
		return transdate;
	}
	public void setTransdate(Date transdate) {
		this.transdate = transdate;
	}
	
	
	
	

}
